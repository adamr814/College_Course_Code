﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoyAdamAssignment04
{
    public class MonthlyDetail
    {
        public int Month {  get; set; }
        public double MonthlyPayment { get; set; }
        public double InterestAmount {  get; set; }
        public double RemainingBalance {  get; set; }

    }
}
